defmodule CreditCardLedger do
  @moduledoc """
  Documentation for `CreditCardLedger`.
  """

  def hello do
    :mundo
  end
end

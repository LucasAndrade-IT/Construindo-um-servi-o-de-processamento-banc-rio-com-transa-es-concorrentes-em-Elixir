defmodule CreditCardLedgerTest do
  use ExUnit.Case

  test "greets the world" do
    assert CreditCardLedger.hello() == :mundo
  end
end

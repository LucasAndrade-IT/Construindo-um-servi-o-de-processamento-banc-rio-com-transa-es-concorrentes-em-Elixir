ExUnit.start()
Ecto.Adapters.SQL.Sandbox.mode(CreditCardLedger.Repo, :manual)
